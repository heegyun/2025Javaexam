import java.util.*;
public class NumberTestGame {

	public static void main(String[] args) {
		
		// 컴퓨터가 1부터100사이의 임의 수 생성하기
		int com, user, count = 0;
		Random rand  = new Random();
		com = rand.nextInt(100)+1;// 1~100
		
		do {
		// user 입력
		//System.out.println(com);
		System.out.print("정답을 추측하여 보시오:  ");
		Scanner scan = new Scanner(System.in);
		user  = scan.nextInt();

		if(com > user) {
			System.out.println("HIGH");
			count++;
		}else if(com < user) {
			System.out.println("LOW");
			count++;
		}else if(com ==  user) {
			System.out.println("정답입니다. ");
		}
		
		
		}while(com != user);
		
		System.out.println("축하합니다.~~");
		System.out.println("게임횟수: " + count);
		
		
		
	}

}
