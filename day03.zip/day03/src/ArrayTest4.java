
public class ArrayTest4 {

	public static void main(String[] args) {
		// 배열의 크기를 정하지 않았다면. 자동 크기조절 되는
		// ArrayList를 사용함
		
		
	}

	
	
	
}
