
public class ArrayTest2 {

	public static void main(String[] args) {
		// 1차원 배열 선언 및 초기화
		String[] toppings = {"Pepperoni", "Mushrooms", "Onions", "Sausage", "Bacon"};
						
		//for(int i = 0; i<toppings.length;i++ ) {
		// for each문으로
		for(String i : toppings ) {
			System.out.println(i);
		}
		
		int list[] = {100,200,300,400,500};
		int total = 0;
		for (int i : list) {
			total = total +i;
		}
		System.out.println(total);
		
		
		

	}

}
