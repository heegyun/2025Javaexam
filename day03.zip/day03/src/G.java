import java.util.Scanner;

public class G {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int dan = 2;
		// System.out.print("구구단의 단을 입력하세요: ");
		// dan = scan.nextInt();
		int i = 1;
		while (dan <= 9) {
			//System.out.println(dan);
			
			while (i < 10) {
				System.out.println(dan + "*" + i + "=" + (dan * i));
				i++;
			}
			i=1;
			dan++;
		}

	}

}
